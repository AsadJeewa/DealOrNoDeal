package game;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import javax.swing.*;

//Create a class to represent the banker
class Banker extends JFrame {
	private double offer;//banker's offer
	private JPanel bankPanel;//panel within banker frame

	//accessor and mutator methods
	public double getOffer() {
		return offer;
	}

	public void setOffer(double offer) {
		this.offer = offer;
	}

	public JPanel getBankPanel() {
		return bankPanel;
	}

	public void setBankPanel(JPanel bankPanel) {
		this.bankPanel = bankPanel;
	}

	//default constructor
	public Banker() {
		setTitle("BANKER");
		setSize(600, 600);
		// frame.pack();
		setLocationRelativeTo(null); // Center the frame
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

		Game.getAudioClip().stop();

		//URL urlForAudio2 = getClass().getResource("sound/dond-think01.wav");
		try {
			Game.urlForAudio = new File("sound/dond-think01.wav").toURI().toURL();
		} catch (Exception e) {
			System.out.println(e);
		}
		Game.setAudioClip3(Applet.newAudioClip(Game.urlForAudio));
		Game.getAudioClip3().loop();

		add(new bankPanel());
		setVisible(true);
	}//end Banker()

	// panel within banker frame
	class bankPanel extends JPanel {
		private JButton deal;
		private JButton noDeal;
		private JLabel offerLabel;
		private double offer;
		private JTextArea offerText;
		private JTextArea prevOffers;

		// double sumLeft;

		public bankPanel() {
			// setFont(new Font("Eurostile", Font.BOLD, 30));
			offerLabel = new JLabel("Bankers Offer:");
			offerLabel.setFont(new Font("Eurostile", Font.BOLD, 30));
			offerText = new JTextArea(1, 20);
			offerText.setFont(new Font("Eurostile", Font.BOLD, 30));
			offerLabel.setForeground(Color.WHITE);
			add(offerLabel);
			offer = calculateOffer();
			Game.getPrevOffersList().add(offer);
			offerText.setText("R" + offer + "0");
			// offerText.setBorder(new LineBorder(Color.WHITE, 5));
			offerText.setEditable(false);
			add(offerText);
			deal = new JButton("deal");
			deal.setFont(new Font("Eurostile", Font.BOLD, 30));
			deal.setBackground(new Color(255, 215, 100));
			deal.setForeground(Color.BLACK);
			noDeal = new JButton("no deal");
			noDeal.setFont(new Font("Eurostile", Font.BOLD, 30));
			noDeal.setBackground(new Color(255, 215, 100));
			noDeal.setForeground(Color.BLACK);
			add(deal);
			deal.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Game.getAudioClip3().stop();
					try {
						Game.urlForAudio = new File("sound/applause2.wav")
								.toURI().toURL();
					} catch (Exception b) {
						System.out.println(b);
					}
					// URL urlForAudio =
					// getClass().getResource("dond-think02.wav");
					Game.setAudioClip4(Applet.newAudioClip(Game.urlForAudio));
					Game.getAudioClip4().play();
					// URL urlForAudio =
					// getClass().getResource("sound/applause2.wav");
					// audioClip3 = Applet.newAudioClip(urlForAudio);
					// audioClip3.play();
					JOptionPane.showMessageDialog(null, "You have won R"
							+ offer + "\nYour box contained R " + Game.getMyAmount()
							+ "0");
					System.exit(0);
				}
			});
			add(noDeal);
			noDeal.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
					Game.getFrame().setEnabled(true);
					Game.getFrame().setVisible(true);
					Game.getAudioClip3().stop();
					Game.getAudioClip().loop();
				}
			});
			if (Game.getCountOffer() >= 1) {
				prevOffers = new JTextArea(1, 20);
				prevOffers.setFont(new Font("Eurostile", Font.BOLD, 20));
				for (int num = 0; num < Game.getPrevOffersList().size() - 1; num++) {
					prevOffers.append("Offer " + (num + 1) + ": R"
							+ Game.getPrevOffersList().get(num) + "0\n");
				}
				add(prevOffers);
			}
			Game.setCountOffer(Game.getCountOffer()+1);
		}//end bankPanel()

		@Override
		protected void paintComponent(Graphics g) {

			super.paintComponent(g);
			Image background = (new ImageIcon("image/dond_thebanker.jpg")
					.getImage());
			g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
		}

	}//end bankPanel

	/*IMP This method calculates the offer that the banker will make to the player
	 * It calculates the avrage value of miney LEFT IN THE GAME, multiplies it by the
	 * (turn number divided by 10)
	 * If this value works out to be higher than th maximium value in play, the banker simply
	 * offers the player the average value of the game
	*/
	public double calculateOffer() {
		Game.setSumLeft(0);
		for (int n = 0; n < Game.getRandomAmounts().size(); n++) {
			Game.setSumLeft(Game.getSumLeft() + Game.getRandomAmounts().get(n));
		}
		double avg = (Game.getSumLeft() / Game.getRandomAmounts().size());
		/*
		 * switch (countOffer) { case 1: avg *= 0.5; break; case 2: avg *=
		 * 0.6; break; case 3: avg *= 0.7; break; case 4: avg *= 0.8; break;
		 * case 5: avg *= 0.9; break; case 6: avg *= 0.975; break; }
		 */
		// System.out.println(sumLeft+" ,"+avg+" ,"+" ,"+count+" , "+(avg/count*10));
		if ((avg * Game.count / 10) > Collections.max(Game.getRandomAmounts()))
			return (Math.round(avg) * 100) / 100;
		else
			return (Math.round(avg * Game.count / 10) * 100) / 100;
	}//end calculateOffer()
}//end Banker