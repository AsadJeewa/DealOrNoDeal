package game;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

class Box extends JButton implements ActionListener {
	private ImageIcon imageIcon = new ImageIcon("image/steel case 2.jpg");
	String text;

	double amount;
	int boxNum;
	Color color = Color.BLACK;

	public Box(String text) {
		this.text = text;
	}

	//accessor and mutator methods
	public void setText(String text) {
		this.text = text;
	}

	public void setImageIcon(ImageIcon imageIcon) {
		this.imageIcon = imageIcon;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public void setBoxNum(int boxNum) {
		this.boxNum = boxNum;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		// g.setColor(new Color(255,215,0));
		g.setFont(new Font("Eurostile", Font.BOLD, 30));

		FontMetrics fm = g.getFontMetrics();
		int width = fm.stringWidth(text);
		int height = fm.getAscent();

		g.drawImage(imageIcon.getImage(), 0, 0, getWidth(), getHeight(),
				this);
		g.setColor(color);
		g.drawString("" + text, (getWidth() / 2) - (width / 2),
				(getHeight() / 2) + (height / 2));
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// JOptionPane.showMessageDialog(null,""+randomAmounts);
		if (Game.count == 0) {
			setAmount(amount);
			setText("" + (boxNum + 1));
			setEnabled(false);
			addActionListener(this);
			Game.setMyAmount(amount);
			// System.out.println(myAmount);
			Game.getBoxes()[boxNum].setVisible(false);
			Game.getTxt().setText("Select " + (6 - Game.count) + " case(s)");
		} else {
			try {
				Game.urlForAudio = new File("sound/click.wav").toURI().toURL();
			} catch (Exception a) {
				System.out.println(a);
			}
			// URL urlForAudio = getClass().getResource("dond-think02.wav");
			Game.setAudioClip2(Applet.newAudioClip(Game.urlForAudio));
			Game.getAudioClip2().play();
			// URL urlForAudio2 = getClass().getResource("sound/click.wav");

			int index = 0;
			// System.out.println(amount + " , " +sumLeft);
			for (int i = 0; i < Game.getRandomAmounts().size(); i++) {
				if (Game.getRandomAmounts().get(i) == amount)
					index = i;
			}
			Game.getRandomAmounts().remove(index);
			setImageIcon(new ImageIcon("image/closed.jpg"));
			// setForeground(new Color(255, 215, 0));
			if (amount == 0.01)
				setText("R " + amount);
			else
				setText("R " + amount + "0");

			// money[getEqualIndex()].setVisible(false);
			Game.getMoney()[getEqualIndex()].setBackground(new Color(51, 51, 0));
			// randomAmounts
			// color = new Color(255,215,0);
			setEnabled(false);
			// setVisible(false);
			// setPressed();
			/*
			 * try{ Thread.sleep(1000L); } catch(Exception b){
			 * System.out.println(b); }
			 */
			if (Game.count > 0 && Game.count < 6)
				Game.getTxt().setText("Select " + (6 - Game.count) + " case(s)");
			else if (Game.count >= 6 && Game.count < 11) {
				if (Game.count == 6) {
					Game.getFrame().setEnabled(false);
					// frame.setVisible(false);
					Banker b = new Banker();
					Game.setOfferFrame(b);
					Game.getOffers().add(b.calculateOffer());
					Game.getOfferFrame().setVisible(true);
				}
				Game.getTxt().setText("Select " + (6 + 5 - Game.count) + " case(s)");
			} else if (Game.count >= 11 && Game.count < 15) {
				if (Game.count == 11) {
					Game.getFrame().setEnabled(false);
					Game.setOfferFrame(new Banker());
					Game.getOfferFrame().setVisible(true);
				}
				Game.getTxt().setText("Select " + (6 + 5 + 4 - Game.count) + " case(s)");
			} else if (Game.count >= 15 && Game.count < 18) {
				if (Game.count == 15) {
					Game.getFrame().setEnabled(false);
					Game.setOfferFrame(new Banker());
					Game.getOfferFrame().setVisible(true);
				}
				Game.getTxt().setText("Select " + (6 + 5 + 4 + 3 - Game.count)
						+ " case(s)");
			} else if (Game.count >= 18 && Game.count < 20) {
				if (Game.count == 18) {
					Game.getFrame().setEnabled(false);
					Game.setOfferFrame(new Banker());
					Game.getOfferFrame().setVisible(true);
				}
Game.getTxt().setText("Select " + (6 + 5 + 4 + 3 + 2 - Game.count)
						+ " case(s)");
			} else if (Game.count == 20) {
				Game.getFrame().setEnabled(false);
				Game.setOfferFrame(new Banker());
				Game.getOfferFrame().setVisible(true);
				Game.getMyBox().setEnabled(true);
				Game.getTxt().setText("Choose your case OR the final case!");
				// txt.setText("Select " + (6 + 5 + 4 + 3 + 2 + 1 - count)
				// + " case(s)");
			} else if (Game.count == 21) {
				if (e.getSource() == Game.getMyBox()) {
					// frame.setEnabled(false);
					// offerFrame = new Banker();
					// offerFrame.setVisible(true);
					if (Game.getMyAmount() == 0.01)
						JOptionPane.showMessageDialog(this,
								"Your box contained R " + Game.getMyAmount());
					else
						JOptionPane.showMessageDialog(this,
								"Your box contained R " + Game.getMyAmount() + "0");
				} else {
					if (amount == 0.01)
						JOptionPane.showMessageDialog(this, "Box "
								+ (boxNum + 1) + " contained R " + amount);
					else
						JOptionPane.showMessageDialog(this, "Box "
								+ (boxNum + 1) + " contained R " + amount
								+ "0");
				}
				System.exit(0);
			}
		}
		// System.out.println(myAmount +","+ amount);

		// System.out.println(randomAmounts);
		// System.out.println("count: "+count);
		repaint();
		Game.count++;

	}

//work out the equal index i.e link between randomAmounts and amounts
	public int getEqualIndex() {
		for (int i = 0; i < Game.getAmounts().length; i++) {
			if (Game.getAmounts()[i] == amount)
				return i;
		}
		return -1;
	}

//	public double getTotal() {
//		return 0.0;
//	}
	
}//end Box