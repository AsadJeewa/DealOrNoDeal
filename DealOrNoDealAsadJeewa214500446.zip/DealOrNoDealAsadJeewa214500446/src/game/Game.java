package game;
import javax.swing.*;

import java.net.URL;
import java.applet.*;

import java.io.*;
import sun.audio.*;

import java.util.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class Game extends JFrame {

	//(Money in bags) Amounts
	private static double[] amounts = new double[22];//store money amounts
	private static double myAmount;//amount within the box you have selected
	private static ArrayList<Double> randomAmounts = new ArrayList<Double>();//store amounts in a random order
	
	//Banker's Offers
	private static ArrayList<Double> offers = new ArrayList<Double>();//arraylist to store banker's offers
	private static ArrayList<Double> prevOffersList = new ArrayList<Double>();//store previous banker offers

	protected static int count;
	private static int  countOffer;
	private static double sumLeft;
	private static JFrame offerFrame;
	
	//GUI
	private	static JFrame frame;
	private static JTextArea txt;//display Instructions
	private static Box myBox;
	private static Box[] boxes = new Box[22];
	private static JLabel[] money = new JLabel[22];
	
//sound
	private static AudioClip audioClip;
	private static AudioClip audioClip2;
	private static AudioClip audioClip3;
	private static AudioClip audioClip4;

	protected static URL urlForAudio;
	
	//help
	private static String helpText = "";
	
	//accessor and mutator methods
	public static  double[] getAmounts() {
		return amounts;
	}

	public static void setAmounts(double[] amounts) {
		Game.amounts = amounts;
	}

	public static double getMyAmount() {
		return myAmount;
	}

	public static void setMyAmount(double myAmount) {
		Game.myAmount = myAmount;
	}

	public static ArrayList<Double> getOffers() {
		return offers;
	}

	public static void setOffers(ArrayList<Double> offers) {
		Game.offers = offers;
	}

	public static ArrayList<Double> getRandomAmounts() {
		return randomAmounts;
	}

	public static void setRandomAmounts(ArrayList<Double> randomAmounts) {
		Game.randomAmounts = randomAmounts;
	}

	public static ArrayList<Double> getPrevOffersList() {
		return prevOffersList;
	}

	public static void setPrevOffersList(ArrayList<Double> prevOffersList) {
		Game.prevOffersList = prevOffersList;
	}

	public static JFrame getFrame() {
		return frame;
	}

	public static void setFrame(JFrame frame) {
		Game.frame = frame;
	}

	public static JTextArea getTxt() {
		return txt;
	}

	public static void setTxt(JTextArea txt) {
		Game.txt = txt;
	}

	public static Box getMyBox() {
		return myBox;
	}

	public static void setMyBox(Box b) {
		Game.myBox = myBox;
	}

	public static Box[] getBoxes() {
		return boxes;
	}

	public static void setBoxes(Box[] boxes) {
		Game.boxes = boxes;
	}
	
	public static JLabel[] getMoney() {
		return money;
	}

	public static void setMoney(JLabel[] money) {
		Game.money = money;
	}

	public static int getCountOffer() {
		return countOffer;
	}

	public static void setCountOffer(int countOffer) {
		Game.countOffer = countOffer;
	}

	public static double getSumLeft() {
		return sumLeft;
	}

	public static void setSumLeft(double sumLeft) {
		Game.sumLeft = sumLeft;
	}

	public static JFrame getOfferFrame() {
		return offerFrame;
	}

	public static void setOfferFrame(JFrame offerFrame) {
		Game.offerFrame = offerFrame;
	}
	
	public static AudioClip getAudioClip() {
		return audioClip;
	}

	public static void setAudioClip(AudioClip audioClip) {
		Game.audioClip = audioClip;
	}

	public static AudioClip getAudioClip2() {
		return audioClip2;
	}

	public static void setAudioClip2(AudioClip audioClip2) {
		Game.audioClip2 = audioClip2;
	}

	public static AudioClip getAudioClip3() {
		return audioClip3;
	}

	public static void setAudioClip3(AudioClip audioClip3) {
		Game.audioClip3 = audioClip3;
	}

	public static AudioClip getAudioClip4() {
		return audioClip4;
	}

	public static void setAudioClip4(AudioClip audioClip4) {
		Game.audioClip4 = audioClip4;
	}

	//default constructor
	public Game() {

		// URL urlForAudio = getClass().getResource("sound/ChillingMusic.wav");
		try {
			urlForAudio = new File("sound/ChillingMusic.wav").toURI().toURL();
		} catch (Exception e) {
			System.out.println(e);
		}
		// URL urlForAudio = getClass().getResource("dond-think02.wav");
		audioClip = Applet.newAudioClip(urlForAudio);
		audioClip.loop();

		setLayout(new BorderLayout(10, 10));

		//populate amounts
		amounts[0] = 0.01;
		amounts[1] = 0.1;
		amounts[2] = 0.5;
		amounts[3] = 1.0;
		amounts[4] = 5.0;
		amounts[5] = 10.0;
		amounts[6] = 50.0;
		amounts[7] = 100.0;
		amounts[8] = 250.0;
		amounts[9] = 500.0;
		amounts[10] = 750.0;
		amounts[11] = 1000.0;
		amounts[12] = 3000.0;
		amounts[13] = 5000.0;
		amounts[14] = 10000.0;
		amounts[15] = 15000.0;
		amounts[16] = 20000.0;
		amounts[17] = 35000.0;
		amounts[18] = 50000.0;
		amounts[19] = 75000.0;
		amounts[20] = 100000.0;
		amounts[21] = 250000.0;

		//randomise amounts
		for (int i = 0; i < amounts.length; i++) {
			randomAmounts.add(new Double(amounts[i]));
		}

		Collections.shuffle(randomAmounts);

		//"Draw" GUI
		JPanel panelCase = new JPanel(new GridLayout(5, 5, 15, 15));
		JPanel panelInstructions = new JPanel(new GridLayout());
		JPanel money1 = new JPanel(new GridLayout(11, 1, 15, 15));
		JPanel money2 = new JPanel(new GridLayout(11, 1, 15, 15));

		for (int num = 0; num < 22; num++) {
			boxes[num] = new Box("" + (num + 1));
			boxes[num].setAmount(randomAmounts.get(num));
			boxes[num].setBoxNum(num);
			boxes[num].addActionListener(boxes[num]);
			panelCase.add(boxes[num]);
		}

		panelCase.add(new JLabel(new ImageIcon("image/download (3).jpg")));
		//panelCase.add(new JLabel(new ImageIcon("image/copyright (3).png")));
		
		JButton helpButton = new JButton("Help");//create a help button
		helpButton.setFont((new Font("Eurostile", Font.BOLD, 30)));
		helpButton.setBorder(new LineBorder(Color.BLACK, 2));
		helpButton.setBackground(new Color(255, 215, 100));
		helpButton.setHorizontalAlignment(JButton.CENTER);
		helpButton.setForeground(Color.BLACK);
		
		/*try{
		Scanner file = new Scanner(new FileReader("text/Help.txt"));
		while(file.hasNext())
		helpText = helpText+""+ file.next();
		}
		catch (FileNotFoundException E){
			JOptionPane.showMessageDialog(null, "ERROR, no help");
		}*/
		
		helpButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent E){
//				ProcessBuilder pb = new ProcessBuilder("Word2013.exe", "text/Dealor NoDeal.docx");
				ProcessBuilder pb = new ProcessBuilder("Notepad.exe", "text/Help.txt");
				    try {
				    	pb.start();
				    }
				    catch (IOException e) {
				      System.out.println(e);
				    } 
				//JOptionPane.showMessageDialog(null, helpText);
			}
		});
		
		panelCase.add(helpButton);
				
		myBox = new Box("Your Case");
		myBox.setBorder(new LineBorder(Color.BLACK, 8));
		panelCase.add(myBox);

		for (int num = 0; num < 11; num++) {
			money[num] = new CustomLabel("R" + amounts[num] + "0");
			if (num == 0)
				money[num].setText("R" + amounts[num]);
			money1.add(money[num]);
		}
		for (int num = 11; num < 22; num++) {
			money[num] = new CustomLabel("R" + amounts[num] + "0");
			money2.add(money[num]);
		}

		txt = new JTextArea("Instructions");
		txt.setEditable(false);
		txt.setFont(new Font("Eurostile", Font.BOLD, 30));
		txt.setForeground(Color.BLACK);
		txt.setAlignmentX(56);
		panelInstructions.add(txt);

		add(panelCase, BorderLayout.CENTER);
		add(panelInstructions, BorderLayout.SOUTH);
		add(money1, BorderLayout.WEST);
		add(money2, BorderLayout.EAST);
	}//end Game()

	public static void main(String[] args) {
//create JFrame and specify properties
		frame = new Game();
		frame.setTitle("DEAL OR NO DEAL");
		// frame.setResizable(false);
		frame.setExtendedState(frame.MAXIMIZED_BOTH);
		// frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		txt.setText("Select a case. This will be your case for the duration of the game");
			}//end main

//inner custom label class to "draw" money labels 	
	class CustomLabel extends JLabel {
		public CustomLabel(String text) {
			super.setText(text);
			setBorder(new LineBorder(Color.BLACK, 2));
			setOpaque(true);
			setBackground(new Color(255, 215, 100));
			setFont(new Font("Eurostile", Font.BOLD, 18));
			setHorizontalAlignment(CENTER);
			setForeground(Color.BLACK);
		}

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(200, 200);
		}
	}//end CustomLabel

}//end Game